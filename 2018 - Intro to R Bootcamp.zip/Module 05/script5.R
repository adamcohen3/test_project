install.packages("devtools")
devtools::install_github("bradleyboehmke/rbootcamp")

library(rbootcamp)
get_tutorial("hello")
get_tutorial("EDA")